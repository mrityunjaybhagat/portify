import 'package:flutter/material.dart';

class ChnagePassword extends StatefulWidget {
  const ChnagePassword({super.key});

  @override
  State<ChnagePassword> createState() => _ChnagePasswordState();
}

class _ChnagePasswordState extends State<ChnagePassword> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
