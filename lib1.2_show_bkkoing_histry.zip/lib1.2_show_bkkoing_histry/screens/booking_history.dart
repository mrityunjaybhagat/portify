import 'package:flutter/material.dart';
import 'package:portify/app_theme.dart';
import 'package:portify/widgets/booking_history_widget.dart';
import 'package:portify/screens/booking_detail_screen.dart';
import 'package:portify/models/booking_model.dart';
import 'package:portify/services/booking_service.dart';

class BookingHistory extends StatefulWidget {
  @override
  _BookingHistoryState createState() => _BookingHistoryState();
}

class _BookingHistoryState extends State<BookingHistory> {
  late Future<List<Booking>> futureBookings;

  @override
  void initState() {
    super.initState();
    futureBookings = BookingService().fetchBookingHistory();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking History',
            style: TextStyle(color: AppTheme.secondaryColor)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.textColor),
      ),
      body: FutureBuilder<List<Booking>>(
        future: futureBookings,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No bookings found'));
          } else {
            return ListView.builder(
              padding: const EdgeInsets.all(15),
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final booking = snapshot.data![index];
                return BookingHistoryWidget(
                  address1: booking.address1,
                  address2: booking.address2,
                  dateTime: booking.dateTime,
                  id: booking.id,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            BookingDetailScreen(booking: booking),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
