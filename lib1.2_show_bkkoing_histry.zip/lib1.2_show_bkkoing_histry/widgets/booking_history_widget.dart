import 'package:flutter/material.dart';
import 'package:portify/app_theme.dart';

class BookingHistoryWidget extends StatelessWidget {
  final String address1;
  final String address2;
  final String dateTime;
  final int id;
  final VoidCallback onTap;

  BookingHistoryWidget({
    required this.address1,
    required this.address2,
    required this.dateTime,
    required this.id,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 10),
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.location_on, color: AppTheme.primaryColor),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    address1,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Icon(Icons.location_on, color: AppTheme.primaryColor),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    address2,
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.calendar_today, color: AppTheme.primaryColor),
                SizedBox(width: 10),
                Text(
                  dateTime,
                  style: TextStyle(fontSize: 16),
                ),
                Spacer(),
                Text(
                  id.toString(),
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
