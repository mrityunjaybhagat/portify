import 'package:flutter/material.dart';
import 'package:portify/models/user_model.dart';
import 'package:portify/services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  User? _user;
  bool _isLoading = false;

  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;
  final AuthService _authService = AuthService();

  Future<void> login(String username, String password) async {
    _isLoading = true;
    notifyListeners();

    _user = await _authService.login(username, password);
    _isLoading = false;
    notifyListeners();
  }

  void logout() {
    _user = null;
    notifyListeners();
  }
}
