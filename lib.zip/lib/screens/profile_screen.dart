import 'package:flutter/material.dart';
import 'package:portify/models/user_model.dart';
import 'package:portify/widgets/app_drawer.dart';

class ProfileScreen extends StatelessWidget {
  final User user;
  final VoidCallback onLogout;

  ProfileScreen({required this.user, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profile')),
      drawer: AppDrawer(user: user, onLogout: onLogout),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              backgroundImage: NetworkImage(user.profilePicture),
              radius: 50,
            ),
            SizedBox(height: 20),
            Text('Username: ${user.username}'),
            Text('Email: ${user.email}'),
            Text('Mobile: ${user.mobile}'),
          ],
        ),
      ),
    );
  }
}
