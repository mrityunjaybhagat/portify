import 'package:flutter/material.dart';
import '../app_theme.dart';

class NextScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Next Screen', style: TextStyle(color: AppTheme.textColor)),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: AppTheme.textColor),
      ),
      body: Center(
        child: Text(
          'This is the next screen!',
          style: TextStyle(color: AppTheme.textColor, fontSize: 24),
        ),
      ),
    );
  }
}
