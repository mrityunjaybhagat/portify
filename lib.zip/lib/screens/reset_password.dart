import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../widgets/CustomTextField.dart';
import '../widgets/submit_button.dart';

class ResetPasswordScreen extends StatelessWidget {
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reset Password',
            style: TextStyle(color: AppTheme.textColor)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.textColor),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              CustomTextField(
                controller: _newPasswordController,
                labelText: 'New Password',
                icon: Icons.lock,
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _confirmPasswordController,
                labelText: 'Confirm Password',
                icon: Icons.lock,
              ),
              const SizedBox(height: 40),
              SubmitButton(
                text: 'Change Password',
                onPressed: () {
                  // Handle change password logic here
                  String newPassword = _newPasswordController.text;
                  String confirmPassword = _confirmPasswordController.text;
                  if (newPassword == confirmPassword) {
                    // Passwords match, proceed with password change
                    print('Password changed successfully!');
                  } else {
                    // Show error message
                    print('Passwords do not match!');
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
