import 'package:flutter/material.dart';

class DocumentFrom extends StatefulWidget {
  const DocumentFrom({super.key});

  @override
  State<DocumentFrom> createState() => _DocumentFromState();
}

class _DocumentFromState extends State<DocumentFrom> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
