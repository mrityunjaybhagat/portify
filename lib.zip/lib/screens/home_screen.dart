import 'package:flutter/material.dart';
import 'package:portify/models/user_model.dart';

class HomeScreen extends StatelessWidget {
  final User user;
  final VoidCallback onLogout;

  HomeScreen({required this.user, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: onLogout,
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Welcome, ${user.username}'),
            Text('Your ID: ${user.id}'),
            //Text('Your Token: ${user.token}'),
            Text('Your Email: ${user.email}'),
            Text('Your Mobile: ${user.mobile}'),
          ],
        ),
      ),
    );
  }
}
