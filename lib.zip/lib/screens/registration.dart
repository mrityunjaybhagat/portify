import 'package:flutter/material.dart';
import 'package:portify/screens/register/bankdetails.dart';
import '../app_theme.dart';
import 'package:portify/widgets/CustomTextField.dart';
import 'package:portify/widgets/otp_input.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final TextEditingController _mobileController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _showOtpField = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Register', style: TextStyle(color: AppTheme.textColor)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: AppTheme.textColor),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomTextField(
                  controller: _mobileController,
                  labelText: 'Mobile Number',
                  icon: Icons.phone,
                ),
                const SizedBox(height: 20),
                if (_showOtpField)
                  OtpInput(
                    onCompleted: (otp) {
                      // Handle OTP verification logic here
                      print('Entered OTP: $otp');
                    },
                  ),
                const SizedBox(height: 20),
                if (_showOtpField)
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          _showOtpField = true;
                        });
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: AppTheme.textColor,
                      backgroundColor: AppTheme.primaryColor,
                    ),
                    child: const Text('Get OTP'),
                  ),
                if (!_showOtpField)
                  ElevatedButton(
                    onPressed: () {
                      if (_mobileController.text.length == 10) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const BankDetailsForm()),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Please type 10 digit number'),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: AppTheme.textColor,
                      backgroundColor: AppTheme.primaryColor,
                    ),
                    child: const Text('Get OTP'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
