import 'package:flutter/material.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFFEAC109);
  static const Color secondaryColor = Color(0xFF3D3D3D);
  static const Color textColor = Color(0xFF3D3D3D);
  static const Color iconColor = Color(0xFFEAC109);
  static const Color inputBorderColor = Color(0xFFEAC109);
}
