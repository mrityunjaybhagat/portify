import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:portify/providers/auth_provider.dart';
import 'package:portify/screens/login_screen.dart'; // Replace with actual screen imports
import 'package:portify/screens/profile_screen.dart'; // Replace with actual screen imports

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AuthProvider(), // Initialize your provider here
      child: MaterialApp(
        title: 'Your App Name',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          // Add more customizations if needed
        ),
        initialRoute: '/', // Specify initial route
        routes: {
          '/': (context) => LoginScreen(), // Replace with your login screen
          '/profile': (context) =>
              ProfileScreen(), // Replace with your profile screen
          // Add more routes for other screens as needed
        },
      ),
    );
  }
}
